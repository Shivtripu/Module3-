package HotelBooking;

public class StepDef {

}
