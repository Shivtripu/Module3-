package HotelBooking;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AlertHotelMessage {
	public static void main(String[] args) throws InterruptedException
	{
		Alert alert;
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/SHIVAMTR/Desktop/Module3%20All%20material/hotelbooking.html");
		Thread.sleep(2000);
		
		driver.findElement(By.id("txtFirstName")).sendKeys("");
		Thread.sleep(2000);
		driver.findElement(By.id("btnPayment")).click();
		alert = driver.switchTo().alert();
		System.out.println("The alert message is:"+ alert.getText());
		alert.accept();
		driver.findElement(By.id("txtFirstName")).sendKeys("Shivam");
		driver.findElement(By.name("txtLN")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		alert = driver.switchTo().alert();
		System.out.println("The alert message is:"+ alert.getText());
		alert.accept();
		driver.findElement(By.name("txtLN")).sendKeys("Tripathi");
		driver.findElement(By.id("txtEmail")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		alert = driver.switchTo().alert();
		System.out.println("The alert message is:"+ alert.getText());
		alert.accept();
		driver.findElement(By.id("txtEmail")).sendKeys("shivam.triapthi@capgemini.com");
		driver.findElement(By.id("txtPhone")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		alert = driver.switchTo().alert();
		System.out.println("The alert message is:"+ alert.getText());
		alert.accept();
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("9876");
		//driver.findElement(By.id("txtPhone")).sendKeys("8400767369");
		Select dropCity= new Select(driver.findElement(By.name("city")));
		dropCity.selectByVisibleText("Select City");
		
		Select dropState= new Select(driver.findElement(By.name("state")));
		dropState.selectByVisibleText("Select State");
		
		
		//driver.findElement(By.id("")).sendKeys("");
		//driver.findElement(By.id("btnPayment")).click();
		
	}
		

}
