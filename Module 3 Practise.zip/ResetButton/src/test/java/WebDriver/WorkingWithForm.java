package WebDriver;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class WorkingWithForm {
	public static void main(String args[])
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get("file:///C:/Users/SHIVAMTR/Desktop/Module3%20All%20material/WorkingWithForms.html");
		driver.findElement(By.id("txtUserName")).sendKeys("Shivam123");
		driver.findElement(By.name("txtPwd")).sendKeys("igate");
		driver.findElement(By.id("txtConfPassword")).sendKeys("igate");
		driver.findElement(By.className("Format1")).sendKeys("Shivam");
		driver.findElement(By.id("txtLastName")).sendKeys("Tripathi");
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		driver.findElement(By.id("DOB")).sendKeys("03/02/1998");	
		driver.findElement(By.name("Email")).sendKeys("shivam.tripathi@capgemini.com");	
		driver.findElement(By.name("Address")).sendKeys("Devi Indryani");
		
		Select dropCity = new Select(driver.findElement(By.name("City")));
		dropCity.selectByVisibleText("Mumbai");
		dropCity.selectByIndex(1);
		dropCity.selectByIndex(2);
		
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("8400767369");
		driver.findElement(By.cssSelector("input[value='Music']")).click();
		driver.findElement(By.cssSelector("input[value='Movies']")).click();
		
		driver.findElement(By.name("submit")).click();  //submit button
	}

}