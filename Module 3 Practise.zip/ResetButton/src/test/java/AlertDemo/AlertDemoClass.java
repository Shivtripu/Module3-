package AlertDemo;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertDemoClass {

	public static void main(String[] args) throws InterruptedException
	{
		WebDriver driver;
		driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\chromedriver.exe");
		
		driver.get("file:///C:/Users/SHIVAMTR/Desktop/Module3%20All%20material/AlertBoxDemos.html");
		Thread.sleep(5000);
		
		Alert alert = driver.switchTo().alert();  //for Alert button
		System.out.println("The alert message is:"+ alert.getText());
		alert.accept();
		Thread.sleep(5000);
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(5000);
		
		Alert confirm = driver.switchTo().alert();  //for Confirm button
		confirm.accept();
		Thread.sleep(5000);
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(5000);
		confirm=driver.switchTo().alert();
		confirm.dismiss();
		Thread.sleep(5000);
		driver.findElement(By.id("prompt")).click();
		Thread.sleep(5000);
		
		Alert prompt= driver.switchTo().alert();  //for Prompt button
		String text= prompt.getText();
		System.out.println(text);
		prompt.sendKeys("Shivam");
		Thread.sleep(5000);
		prompt.accept();
		Thread.sleep(5000);
		prompt=driver.switchTo().alert();
		prompt.dismiss();
		Thread.sleep(5000);
		driver.quit();  //browser close is done 
	}

}
