package HotelManagement;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.HotelBookingPageFactory;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	public WebDriver driver;
	public HotelBookingPageFactory objhdpg ;
	
	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHIVAMTR\\Desktop\\Module3 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		objhdpg = new HotelBookingPageFactory(driver);
		driver.get("C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\hotelbooking.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title= driver.getTitle();
		if(title.contentEquals("Hotel Booking")) 
			System.out.println("***Welcome***");
		else
			System.out.println("***Title Not Matched***");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user enters all valid date$")
	public void user_enters_all_valid_date() throws Throwable {
		objhdpg.setPffname("Shivam");
		Thread.sleep(1000);
		objhdpg.setPflname("Tripathi");
		Thread.sleep(1000);
		objhdpg.setPfemail("shivam.tripathi@capgemini.com");
		Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");
		Thread.sleep(1000);
		objhdpg.setPfcity("Pune"); Thread.sleep(1000);
		objhdpg.setPfpersons(5); Thread.sleep(1000);
		objhdpg.setPfcardholder("Shivam Tripathi");Thread.sleep(1000);
		objhdpg.setPfdebit("5000");Thread.sleep(1000);
		objhdpg.setPfcvv("455");Thread.sleep(1000);
		objhdpg.setPfmonth("5");Thread.sleep(1000);
		objhdpg.setPfyear("2020");Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		objhdpg.setPfbutton();
		driver.close();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}
	
	@When("^user leaves first Name blank and clicks the button$")
	public void user_leaves_first_Name_blank_and_clicks_the_button() throws Throwable {
		objhdpg.setPffname("");
		Thread.sleep(1000);
	}
	
	@When("^clicks the button$")
	public void clcik_the_button() throws Throwable{
		objhdpg.setPfbutton();
	}
	
	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    System.out.println("******"+ alertMessage);
	    driver.close();
	}

	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
		objhdpg.setPffname("Shivam");  Thread.sleep(1000);
		objhdpg.setPflname("");  Thread.sleep(1000);
		objhdpg.setPfbutton();
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi");	Thread.sleep(1000);
		objhdpg.setPfemail("Shivam.tripathi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Pune");	Thread.sleep(1000);
		objhdpg.setPfstate("Maharashtra");	Thread.sleep(1000);
		objhdpg.setPfpersons(5); Thread.sleep(1000);
		objhdpg.setPfcardholder("Shivam Triapthi");	 Thread.sleep(1000);
		objhdpg.setPfdebit("9898989696967474");	 Thread.sleep(1000);
		objhdpg.setPfcvv("366"); Thread.sleep(1000);
		objhdpg.setPfmonth("5");  Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		objhdpg.setPfbutton(); 
		driver.close();
	}

	@When("^user enters incorrect email formate and clicks the button$")
	public void user_enters_incorrect_email_formate_and_clicks_the_button() throws Throwable {
		objhdpg.setPfemail("shiv21.@.com");
		objhdpg.setPfbutton();
	}

	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("");	Thread.sleep(1000);
		objhdpg.setPfbutton();
	    
	}

	@When("^user enters incorrect mobileNo formate and clicks the button$")
	public void user_enters_incorrect_mobileNo_formate_and_clicks_the_button(DataTable arg1) throws Throwable {
//	     Write code here that turns the phrase above into concrete actions
//	     For automatic transformation, change DataTable to one of
//	     List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
//	     E,K,V must be a scalar (String, Integer, Date, enum etc)
		
		objhdpg.setPffname("Shivam");  Thread.sleep(1000);
		objhdpg.setPflname("Tripathi");  Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		List<String> objList = arg1.asList(String.class);
		objhdpg.setPfbutton();
		
		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
			System.out.println("***** Matched" + objList.get(i) + "*****");
			}
			else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
			}
		}
	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Select City");	Thread.sleep(1000);
		objhdpg.setPfbutton();
	    
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Pune");	Thread.sleep(1000);
		objhdpg.setPfstate("Select State");	Thread.sleep(1000);
		objhdpg.setPfbutton();
	    
	}

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Pune");	Thread.sleep(1000);
		objhdpg.setPfstate("Select State");	Thread.sleep(1000);
		objhdpg.setPfpersons(arg1);	Thread.sleep(2000);
	    
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		if(arg2 <=3) {
	    	System.out.println("***** 1 room");
	    	assertEquals(1, arg1);
	    }
	    else if(arg2 <=6){
	    	System.out.println("***** 2 rooms");
	    	assertEquals(2, arg1); 	
	    }	 
	    else if(arg2 <=9){
	    	System.out.println("***** 3 rooms");
	    	assertEquals(3, arg1); 	
	    }
	    
	}

	@When("^user leaves CaredHolderName blank and clicks the button$")
	public void user_leaves_CaredHolderName_blank_and_clicks_the_button() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Pune");	Thread.sleep(1000);
		objhdpg.setPfstate("Maharastra");	Thread.sleep(1000);
		objhdpg.setPfpersons(7);	Thread.sleep(1000);
		objhdpg.setPfcardholder("");	Thread.sleep(1000);
		objhdpg.setPfbutton();
	    
	}

	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Pune");	Thread.sleep(1000);
		objhdpg.setPfstate("Maharastra");	Thread.sleep(1000);
		objhdpg.setPfpersons(7);	Thread.sleep(1000);
		objhdpg.setPfcardholder("Shivam Tripathi");	Thread.sleep(1000);
		objhdpg.setPfdebit("");	 Thread.sleep(1000);
	    
	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Pune");	Thread.sleep(1000);
		objhdpg.setPfstate("Maharastra");	Thread.sleep(1000);
		objhdpg.setPfpersons(7);	Thread.sleep(1000);
		objhdpg.setPfcardholder("Shivam Tripathi");	Thread.sleep(1000);
		objhdpg.setPfdebit("9898989696967474");	 Thread.sleep(1000);
		objhdpg.setPfcvv("366"); Thread.sleep(1000);
		objhdpg.setPfmonth("");  Thread.sleep(1000);
	    
	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Throwable {
		objhdpg.setPffname("Shivam");	Thread.sleep(1000);
		objhdpg.setPflname("Tripathi"); 	Thread.sleep(1000);
		objhdpg.setPfemail("shivam.triapthi@capgemini.com");	Thread.sleep(1000);
		objhdpg.setPfmobile("8400767369");	Thread.sleep(1000);
		objhdpg.setPfcity("Pune");	Thread.sleep(1000);
		objhdpg.setPfstate("Maharastra");	Thread.sleep(1000);
		objhdpg.setPfpersons(7);	Thread.sleep(1000);
		objhdpg.setPfcardholder("Shivam Tripathi");	Thread.sleep(1000);
		objhdpg.setPfdebit("9898989696967474");	 Thread.sleep(1000);
		objhdpg.setPfcvv("366"); Thread.sleep(1000);
		objhdpg.setPfmonth("5");  Thread.sleep(1000);
		objhdpg.setPfyear("");  Thread.sleep(1000);
		objhdpg.setPfbutton();
	    
	}

}
