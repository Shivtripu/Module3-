package Login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.interactions.SendKeyToActiveElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef 
{
	WebDriver driver;
	
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement username;
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement password;
	@FindBy(xpath="//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement login;
	public WebElement getLogin() {
		return login;
	}

	public void setLogin(WebElement login) {
		this.login = login;
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\login.html");
	}

	@When("^User enters correct UserName and Password$")
	public void user_enters_correct_UserName_and_Password() throws Throwable {
	    setUsername("Capgemini");
	    setPassword("Capgemini1234");
	}

	@Then("^Redirect to the hotel booking page$")
	public void redirect_to_the_hotel_booking_page() throws Throwable {
		driver.navigate().to("C:\\Users\\SHIVAMTR\\Desktop\\Module3 All material\\hotelbooking.html");
	    Thread.sleep(1000);
	}

	@When("^user leaves UserName blank$")
	public void user_leaves_UserName_blank() throws Throwable {
	    setUsername("");
	    Thread.sleep(1000);
	}

	@Then("^Alert message popup$")
	public void alert_message_popup() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    System.out.println("******"+ alertMessage);
	    driver.close();
	    
	}

	@When("^user leaves Password blank$")
	public void user_leaves_Password_blank() throws Throwable {
		setUsername("Capgemini123");
		setPassword("");
		Thread.sleep(1000);
	}

	@When("^user enters UserNameshivam and Password(\\d+)$")
	public void user_enters_UserNameshivam_and_Password(int arg1) throws Throwable {
		setUsername("shivam");
		setPassword("123456");
		Thread.sleep(1000);
	}

	@When("^user enters UserNameyash and Password(\\d+)$")
	public void user_enters_UserNameyash_and_Password(int arg1) throws Throwable {
		setUsername("yash");
		setPassword("000000");
		Thread.sleep(1000);
	}

	@When("^user enters UserNameRahul and Password(\\d+)$")
	public void user_enters_UserNameRahul_and_Password(int arg1) throws Throwable {
		setUsername("Rahul");
		setPassword("987654");
		Thread.sleep(1000);
	}
	

}
